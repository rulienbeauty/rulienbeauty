# Rulien Beauty GitHub Website

这是一个可以直接上传到 GitHub Pages 的静态网站原型。

## 文件
- index.html
- style.css
- assets/rulien-logo.png

## 上传到 GitHub
1. 新建一个 GitHub repository
2. 把这些文件上传到根目录
3. 进入 Settings → Pages
4. Source 选择 Deploy from a branch
5. Branch 选择 main / root
6. 保存后等待 1-3 分钟生成网址

## 需要你后续替换
- 产品真实图片
- 证书图片
- 工厂图片
- Formspree 表单 ID
